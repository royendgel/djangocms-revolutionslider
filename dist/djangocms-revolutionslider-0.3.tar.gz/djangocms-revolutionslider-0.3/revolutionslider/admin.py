from django.contrib import admin
from models import Slide
from models import Slider

admin.site.register(Slider)
admin.site.register(Slide)